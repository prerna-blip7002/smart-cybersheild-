# Smart Cyber Shield
A working hackathon prototype for rule-based cyber threat detection and guided incident response.

## Run
Open `index.html` in a modern browser, or host it using GitHub Pages. No installation, dependencies or server required.

## Demo in 60 seconds
1. Load demo events: five events produce four alerts.
2. Review the high-risk endpoint or repeated login failure incident.
3. Acknowledge it, tick response steps, simulate containment and mark it resolved.
4. Paste another JSON event array and click Analyze events.
5. Export the incident report as JSON.

## Detection logic
- Explicit malicious flag: 90 points.
- At least five failed logins: min(85, 50 + 2 × attempts).
- Suspicious link flag: 70 points.
- Outbound bytes above 100,000,000: 65 points.
Scores add up and are capped at 100. High severity starts at 80; medium starts at 50. Scores are heuristic priorities, not probabilities or ML confidence.

## Scope and limitations
All bundled events are synthetic. This frontend prototype does not monitor real networks, execute containment, scan links, authenticate users or use a trained AI model. Actions update in-memory demo records; refreshing resets them. Do not paste confidential production logs. Future work includes authenticated APIs, log integrations, persistent incident storage and validated anomaly detection.

## Stack
HTML, CSS and vanilla JavaScript; responsive layout; browser-side processing; no external assets.

## GitHub Pages
Upload index.html and README.md at the repository root. In Settings > Pages, select Deploy from a branch, main, /(root), and Save. GitHub provides the website URL after deployment.
